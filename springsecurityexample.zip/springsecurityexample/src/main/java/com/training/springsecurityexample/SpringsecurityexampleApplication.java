package com.training.springsecurityexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringsecurityexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringsecurityexampleApplication.class, args);
	}

}
