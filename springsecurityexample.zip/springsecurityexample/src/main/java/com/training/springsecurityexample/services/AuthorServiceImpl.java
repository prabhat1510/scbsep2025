package com.training.springsecurityexample.services;

import com.training.springsecurityexample.entities.Author;
import com.training.springsecurityexample.exceptions.AuthorNotFoundException;
import com.training.springsecurityexample.repositories.AuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthorServiceImpl implements AuthorService {
    @Autowired
    private AuthorRepository authorRepository;
    @Override
    public Author createAuthor(Author author) {
        return authorRepository.save(author);
    }

    @Override
    public Author findById(Long id) throws AuthorNotFoundException {
        if (authorRepository.findById(id).isPresent()) {
            return authorRepository.findById(id).get();
        }
       throw new AuthorNotFoundException("Author with id "+id+" not found");
    }

    @Override
    public Author updateAuthor(Author author) throws AuthorNotFoundException {
        if(authorRepository.existsById(author.getAuthorId())){
            Author authr = authorRepository.save(author);
            return authr;
        }
       throw new AuthorNotFoundException("Author with id "+author.getAuthorId()+" not found");
    }

    @Override
    public List<Author> findAll() {
        return authorRepository.findAll();
    }

    @Override
    public String deleteAuthorById(Long id) throws AuthorNotFoundException {
        if(authorRepository.existsById(id)){
                authorRepository.deleteById(id);
            return "Author with id "+id+" deleted";
        }
        throw new AuthorNotFoundException("Author with id "+id+" not found");
    }

    @Override
    public List<Author> findByName(String name) throws AuthorNotFoundException {
        return authorRepository.findByName(name);
    }
}
