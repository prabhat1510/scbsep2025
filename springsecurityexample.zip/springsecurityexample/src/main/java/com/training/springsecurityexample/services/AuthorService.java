package com.training.springsecurityexample.services;

import com.training.springsecurityexample.entities.Author;
import com.training.springsecurityexample.exceptions.AuthorNotFoundException;

import java.util.List;

public interface AuthorService {
    //Create
    public Author createAuthor(Author author);
    //Retrieve by primary key
    public Author findById(Long id) throws AuthorNotFoundException;
    //Update
    public Author updateAuthor(Author author) throws AuthorNotFoundException;
    //Find All
    public List<Author> findAll();

    //Delete
    public String deleteAuthorById(Long id) throws AuthorNotFoundException;
    //FindByName
    public List<Author> findByName(String name) throws AuthorNotFoundException;

}
