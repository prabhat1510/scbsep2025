package com.training.springsecurityexample.controller;

import com.training.springsecurityexample.entities.Book;
import com.training.springsecurityexample.exceptions.BookNotFoundException;
import com.training.springsecurityexample.services.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/book")
public class BookController {
    @Autowired
    private BookService bookService;

    //Create
    @PostMapping("/new")
    public Book createBook(@RequestBody Book book){
        return bookService.createBook(book);
    }
    //Retrieve by primary key
    @GetMapping("/get/{id}")
    public Book findById(@PathVariable("id") Long id) throws BookNotFoundException {
            return bookService.findById(id);
    }
}
