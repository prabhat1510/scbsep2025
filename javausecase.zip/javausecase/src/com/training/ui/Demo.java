package com.training.ui;

import com.training.model.Customer;
import com.training.service.CustomerService;
import com.training.service.CustomerServiceImpl;

import java.util.Scanner;

public class Demo {
    public static void main(String[] args) {
        CustomerService service = new CustomerServiceImpl();
        Customer customer = new Customer();
        while(true) {
            System.out.println("Welcome to Standard Chartered Bank");
            System.out.println("Please enter your choice");
            System.out.println("1 for Add new Customer");
            System.out.println("2 for Display Customer");
            System.out.println("3 for Search Customer");
            System.out.println("4 for Delete Customer");
            System.out.println("5 for Exit the bank application");
            Scanner sc = new Scanner(System.in);
            Integer choice = sc.nextInt();
            switch (choice) {
                case 1 :
                    System.out.println("Please enter customer details : ");

                    Scanner sc1 = new Scanner(System.in);
                    System.out.println("Enter customerId : ");
                    Integer customerID = sc1.nextInt();
                    System.out.println("Enter name : ");
                    String name = sc1.next();
                    System.out.println("Enter email : ");
                    String email = sc1.next();
                    System.out.println("Enter contact : ");
                    String contact = sc1.next();
                    System.out.println("Enter account type (Savings or Current) : ");
                    String accountType = sc1.next();
                    customer.setName(name);
                    customer.setContact(contact);
                    customer.setAccountType(accountType);
                    customer.setCustomerId(customerID);
                    customer.setEmail(email);
                    String message = service.addCustomer(customer);
                    System.out.println(message);
                     break;
                     case 2 :
                         break;
                         case 5 :
                             System.exit(0);
                         default :
                             System.out.println("Invalid choice");
            }
        }
    }
}
