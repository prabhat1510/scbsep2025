package com.training.collectionsex;

import java.util.*;

public class MapExample {
    public static void main(String[] args) {
        Map<Integer,String> map = new HashMap<Integer,String>();
        map.put(1,"Sam");
        map.put(2,"Joe");
        map.put(3,"Jill");
        map.put(null,"Jane");
        map.put(5,null);
        map.put(2,"Jill");
        System.out.println(map);
        Set<Integer> set = map.keySet();
        Iterator<Integer> itr = set.iterator();
        while(itr.hasNext()){
            Integer key = itr.next();
            System.out.println("key: "+key+" value: "+map.get(key));
        }
    }
}
