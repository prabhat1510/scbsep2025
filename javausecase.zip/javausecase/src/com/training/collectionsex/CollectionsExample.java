package com.training.collectionsex;

import java.util.*;

public class CollectionsExample {
    public static void main(String[] args) {
        Collection c;
        List<Integer> list = new ArrayList<Integer>();
        List<String> listOfString = new ArrayList<String>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(1);
        list.add(2);
        System.out.println(list);
        listOfString.add("a");
        listOfString.add("b");
        listOfString.add("e");
        listOfString.add("d");
        listOfString.add("e");
        System.out.println(listOfString);
        Iterator<String> it = listOfString.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }
        //forEach -- we are passing method reference of println method
        listOfString.forEach(System.out::println);
        for (int i = 0; i < listOfString.size(); i++) {
            System.out.println(listOfString.get(i));
        }
        for(String s: listOfString){
            System.out.println(s);
        }
    }
}
