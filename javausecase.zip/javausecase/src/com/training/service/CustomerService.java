package com.training.service;

import com.training.exceptions.CustomerNotFoundException;
import com.training.model.Customer;

public interface CustomerService {
    //Create
    public String addCustomer(Customer customer);
    //Retrieve
    public Customer findCustomerById(Integer id) throws CustomerNotFoundException;
    //Update
    public Customer updateCustomer(Customer customer) throws CustomerNotFoundException;
    //Delete
    public String deleteCustomer(Integer id) throws CustomerNotFoundException;
}
