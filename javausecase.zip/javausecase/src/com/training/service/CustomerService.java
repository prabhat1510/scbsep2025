package com.training.service;

import com.training.model.Customer;

public interface CustomerService {
    //Create
    public String addCustomer(Customer customer);
    //Retrieve
    public Customer findCustomerById(Integer id);
    //Update
    public Customer updateCustomer(Customer customer);
    //Delete
    public String deleteCustomer(Integer id);
}
