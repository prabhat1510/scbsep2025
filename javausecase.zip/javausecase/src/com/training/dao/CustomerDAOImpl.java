package com.training.dao;

import com.training.model.Customer;

public class CustomerDAOImpl implements CustomerDAO {
    private static Customer[] customers = new  Customer[10];

    @Override
    public String addCustomer(Customer customer) {
        customers[0]=customer;
        return "Customer added  successfully";
    }

    @Override
    public Customer findCustomerById(Integer id) {
        for(Customer customer : customers) {
            if(customer.getCustomerId().equals(id)) {
                return customer;
            }
        }
        return null;
    }

    @Override
    public Customer updateCustomer(Customer customer) {
        return null;
    }

    @Override
    public String deleteCustomer(Integer id) {
        return "";
    }
}
