package com.training.dao;

import com.training.exceptions.CustomerNotFoundException;
import com.training.model.Customer;

import java.sql.*;

public class CustomerDAOImpl implements CustomerDAO {
    //private static Customer[] customers = new  Customer[10];
    private final String url="jdbc:postgresql://localhost:5432/scbsep2025";
    private final String username="postgres";
    private final String password="password";


    @Override
    public String addCustomer(Customer customer) {
       // customers[0]=customer;
        try {
            Connection connection = DriverManager.getConnection(url,username,password);
            String sqlQuery="insert into customer values (?,?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setInt(1,customer.getCustomerId());
            preparedStatement.setString(2,customer.getName());
            preparedStatement.setString(3,customer.getContact());
            preparedStatement.setString(4,customer.getAccountType());
            preparedStatement.setString(5,customer.getEmail());
            int rowCount = preparedStatement.executeUpdate();
            if(rowCount>0){
                return "Customer added successfully";
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


        return "Unable to add Customer";
    }

    @Override
    public Customer findCustomerById(Integer id) throws CustomerNotFoundException{
       /* for(Customer customer : customers) {
            if(customer.getCustomerId().equals(id)) {
                return customer;
            }
        }*/
       throw new CustomerNotFoundException("Customer with id " + id + " not found");
    }

    @Override
    public Customer updateCustomer(Customer customer) throws CustomerNotFoundException {
        return null;
    }

    @Override
    public String deleteCustomer(Integer id) throws CustomerNotFoundException{
        return "";
    }
}
