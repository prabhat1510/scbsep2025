package com.training.springsecurityexample.controller;

import com.training.springsecurityexample.entities.Author;
import com.training.springsecurityexample.exceptions.AuthorNotFoundException;
import com.training.springsecurityexample.services.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/author")
public class AuthorController {
    @Autowired
    private AuthorService authorService;
    //Create
    @PostMapping("/new")
    public Author createBook(@RequestBody Author author){
        return authorService.createAuthor(author);
    }
    //Retrieve by primary key
    @GetMapping("/get/{id}")
    public Author findById(@PathVariable("id") Long id) throws AuthorNotFoundException {
            return authorService.findById(id);
    }

    //Update
    @PutMapping("/update")
    public Author updateAuthor(@RequestBody  Author author) throws AuthorNotFoundException{
        return authorService.updateAuthor(author);
    }
    //Find All
    @GetMapping("/all")
    public List<Author> findAll(){
        return authorService.findAll();
    }

    //Delete
    @DeleteMapping("/delete/{id}")
    public String deleteAuthorById(@PathVariable("id") Long id) throws AuthorNotFoundException{
        return authorService.deleteAuthorById(id);
    }
    //FindByName
    @GetMapping("/name/{name}")
    public List<Author> findByName(@PathVariable("name") String name) throws AuthorNotFoundException{
        return authorService.findByName(name);
    }
}
