package com.training.springsecurityexample.services;

import com.training.springsecurityexample.entities.Book;
import com.training.springsecurityexample.exceptions.BookNotFoundException;
import com.training.springsecurityexample.repositories.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookServiceImpl implements BookService {
    @Autowired
    private BookRepository bookRepository;

    @Override
    public Book createBook(Book book) {
        return bookRepository.save(book);
    }

    @Override
    public Book findById(Long id) throws BookNotFoundException {
        Optional<Book> book = bookRepository.findById(id);
        if (book.isPresent()) {
            return book.get();
        }
        throw new BookNotFoundException("Book with id "+ id +" not found");
    }

    @Override
    public Book updateBook(Book book) throws BookNotFoundException {
        if(bookRepository.existsById(book.getBookId())){
            return bookRepository.save(book);
        }
        throw new BookNotFoundException("Book with id "+ book.getBookId() +" not found");
    }

    @Override
    public List<Book> findAll() {
        return bookRepository.findAll();
    }

    @Override
    public String deleteBookById(Long id) throws BookNotFoundException {
        if (bookRepository.existsById(id)) {
            bookRepository.deleteById(id);
            return "Book with id "+ id + " deleted";
        }
       throw new BookNotFoundException("Book with id "+ id +" not found");
    }

    @Override
    public List<Book> findByTitle(String title) throws BookNotFoundException {
        List<Book> books = bookRepository.findByTitle(title);
        if (books.isEmpty()) {
            throw new BookNotFoundException("Book with title "+title+" not found");
        }
        return books;
    }
}
