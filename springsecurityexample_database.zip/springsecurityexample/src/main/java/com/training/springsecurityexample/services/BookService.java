package com.training.springsecurityexample.services;

import com.training.springsecurityexample.entities.Book;
import com.training.springsecurityexample.exceptions.BookNotFoundException;

import java.util.List;

public interface BookService {
        //Create
        public Book createBook(Book book);
        //Retrieve by primary key
        public Book findById(Long id) throws BookNotFoundException;
        //Update
        public Book updateBook(Book book) throws BookNotFoundException;
        //Find All
        public List<Book> findAll();

        //Delete
        public String deleteBookById(Long id) throws BookNotFoundException;
        //FindByName
        public List<Book> findByTitle(String title) throws BookNotFoundException;

}
