package com.training.springsecurityexample.entities;

public enum ERole {
    ROLE_USER,ROLE_ADMIN
}